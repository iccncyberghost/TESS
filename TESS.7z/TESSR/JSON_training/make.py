f = open("/root/Desktop/TESSR/conv/cnv.txt", "r")
a=f.readlines()
for i in range(0,len(a),2):
      print('{"tag": "test'+str(i)+'",')
      print('"patterns": ["'+a[i]+'"],')
      print('"responses": ["'+a[i+1]+'"],')
      print('"context_set": ""')
      print(' },')
